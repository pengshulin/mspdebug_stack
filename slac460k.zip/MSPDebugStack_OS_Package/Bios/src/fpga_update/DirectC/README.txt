Please download DirectC from http://www.actel.com/download/program_debug/directc/dc27.aspx

Place the following files in this directory.

dpalg.c
dpalg.h
dpchain.c
dpchain.g
dpcom.c
dpcom.h
dpcore.c
dpcore.h
dpdef.h
dpfrom.c
dpfrom.h
dpjtag.c
dpjtag.h
dpnvm.c
dpnvm.h
dpsecurity.c
dpsecurity.h
dpuser.c
dpuser.h
dputil.c
dputil.h
